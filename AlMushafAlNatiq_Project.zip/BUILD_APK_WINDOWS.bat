@echo off
chcp 65001 >nul
echo ============================================
echo   المصحف الناطق - بناء نسخة Android التجريبية
echo ============================================
if not exist gradlew.bat (
  echo لم يتم العثور على Gradle Wrapper.
  echo افتح المجلد من Android Studio ثم اختر Sync Project with Gradle Files.
  echo بعد إنشاء Gradle Wrapper شغّل هذا الملف مرة أخرى.
  pause
  exit /b 1
)
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo فشل البناء. راجع رسالة الخطأ في Android Studio.
  pause
  exit /b 1
)
echo.
echo تم إنشاء APK في:
echo app\build\outputs\apk\debug\app-debug.apk
pause
